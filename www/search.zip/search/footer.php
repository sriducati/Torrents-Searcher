
<div class="row" style="padding-top:50px;">
  <div class="panel-footer container-fluid navbar-fixed-bottom">
    <div class="text-center">Copyright SriHost © 2015</div>
  </div>
</div>



</div><!-- /container -->



</body>
</html> 