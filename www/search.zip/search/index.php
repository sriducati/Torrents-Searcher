
<?php
include("header.php");
?>
  <div class="row">
    <div class="col-sm-12">
      <div class="col-md-12 total_torrents" style="background-color:#1C242E;padding: 12px;border-top-left-radius: 15px;border-top-right-radius: 15px;color:#fff;">
            
          </div>
            <div class="col-md-12" style="background-color:#97A4A6;color:#fff;">
              <ul class="order_list">
                <li><a href="#menu2">Size</a></li>
                 <li><a href="#menu2">Date</a></li>
                <li><a href="#menu1">Seeds</a></li>
                <li><a href="#menu2">Peers</a></li>
              </ul>
            </div>

      <div class="tabs-left">
        <div class="tab-content">
          <div class="tab-pane active torrent_data" id="a" style="height: auto;">


             <!-- Modal -->
            <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false" style="top:15%;outline:none;">
              <div class="modal-dialog" style="width: 175px;">
                <div class="modal-content">
                  <!--<div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Modal title</h4>
                  </div>-->
                  <div class="modal-body" style="padding:0;">
                   <img src="assets/images/loading.gif" style="width:175px;"/>
                  </div>
                  <!--<div class="modal-footer">Modal Footer Content
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                  </div>-->
                </div><!-- /.modal-content -->
              </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->


          <!--<div class="col-md-12" id="loading" style="display:none;background-color:black;">
            <div class="col-md-5">
            </div>
            <div class="col-md-7">
                          <img src="/images/loading.gif"/>

            </div>
          </div>-->

          <ul class="list-group pull-left" id="all_torrents">

          </ul>

          </div>
        </div><!-- /tab-content -->
      </div><!-- /tabbable -->
        <div class="col-md-12" style="background-color:#1C242E;padding: 12px;border-bottom-left-radius: 15px;border-bottom-right-radius: 15px;height:60px;">
            <ul class="pagination pagination-sm pull-right" style="padding:0;margin:0;">
              
            </ul>
        </div>

       

    </div><!-- /col -->
  </div><!-- /row -->
<script>
$(document).ready(function(){

  fetch("",current_page_number);
});
</script>

<?php
include("footer.php");
?>